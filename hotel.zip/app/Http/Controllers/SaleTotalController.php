<?php

namespace App\Http\Controllers;

use App\Models\SaleTotal;
use Illuminate\Http\Request;

class SaleTotalController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\SaleTotal  $saleTotal
     * @return \Illuminate\Http\Response
     */
    public function show(SaleTotal $saleTotal)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\SaleTotal  $saleTotal
     * @return \Illuminate\Http\Response
     */
    public function edit(SaleTotal $saleTotal)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\SaleTotal  $saleTotal
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, SaleTotal $saleTotal)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\SaleTotal  $saleTotal
     * @return \Illuminate\Http\Response
     */
    public function destroy(SaleTotal $saleTotal)
    {
        //
    }
}
