<?php

namespace App\Http\Controllers;

use App\Models\ReservationState;
use Illuminate\Http\Request;

class ReservationStateController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\ReservationState  $reservationState
     * @return \Illuminate\Http\Response
     */
    public function show(ReservationState $reservationState)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\ReservationState  $reservationState
     * @return \Illuminate\Http\Response
     */
    public function edit(ReservationState $reservationState)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\ReservationState  $reservationState
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ReservationState $reservationState)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\ReservationState  $reservationState
     * @return \Illuminate\Http\Response
     */
    public function destroy(ReservationState $reservationState)
    {
        //
    }
}
