<?php

namespace Database\Factories;

use App\Models\ReservationGuest;
use Illuminate\Database\Eloquent\Factories\Factory;

class ReservationGuestFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = ReservationGuest::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
