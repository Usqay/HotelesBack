<?php

namespace Database\Factories;

use App\Models\RoomPrice;
use Illuminate\Database\Eloquent\Factories\Factory;

class RoomPriceFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = RoomPrice::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
