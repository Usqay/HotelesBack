<?php

namespace Database\Factories;

use App\Models\SunatCode;
use Illuminate\Database\Eloquent\Factories\Factory;

class SunatCodesFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = SunatCode::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
