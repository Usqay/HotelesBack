@extends('layouts.app')

@section('content')
    @include('currencies.register')
@endsection